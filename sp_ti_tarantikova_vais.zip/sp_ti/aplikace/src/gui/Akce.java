package gui;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import program.Hlavni;
import program.Loader;

/**
 * Trida slouzi k uchovani vsech akci.
 * @author Deni Tarantikova, Radek Vais
 * @version 7. 12. 2014
 */
public class Akce {

	/** konec programu */
	public static AbstractAction konec = new Akce().new KonecAkce();
	/** napoveda */
	public static AbstractAction napoveda = new Akce().new NapovedaAkce();
	/** nacteni automatu ze souboru */
	public static AbstractAction automatSoubor = new Akce().new NactiAutomatSouborAkce();
	
	
	/**zacatek logovani*/
	public static AbstractAction sLog = new Akce().new StartLogAkce();
	/**konec logovani*/
	public static AbstractAction kLog = new Akce().new KonecLoguAkce();
	
	/** reset automatu */
	public static AbstractAction reset = new Akce().new ResetAkce();
	/** krok podle znaku */
	public static AbstractAction vstup = new Akce().new ZnakAkce();
	/** vloz retezec ke zpracovani */
	public static AbstractAction string = new Akce().new NactiRetezecAkce();
	/** vloz retezec ze souboru ke zpracovani */
	public static AbstractAction stringSoubor = new Akce().new NactiRetezecSouborAkce();
	/** zpracuje znak ze vstupu */
	public static AbstractAction krokVpred = new Akce().new KrokVpredAkce();
	/** vrati znak do vstupu */
	public static AbstractAction krokVzad = new Akce().new KrokVzadAkce();
	
//===================================================================================================================

	/**
	 * Posune automat o krok dopredu.
	 * @param c zpracovavany znak
	 * @return boolean, zda se operace povedla
	 */
	public static boolean vpred(char c) {
		if(!Hlavni.automat.jePrvkemVstupu(c)){
			JOptionPane.showMessageDialog(Hlavni.okno, "Zadan� znak nen� prvkem vstupn� abecedy.\n"
					+ "Automat ho bude ignorovat.",	"Chyba vstupu", JOptionPane.WARNING_MESSAGE);
			return false;
		}else{
			return Hlavni.automat.zpracujVstup(c);
		}
		
	}
	
	/**
	 * Vrati automat o krok zpet.
	 * @param c zpracovavany znak
	 * @return boolean, zda se operace povedla
	 */
	public static boolean vzad(char c) {
		if(!Hlavni.automat.jePrvkemVstupu(c)){
			JOptionPane.showMessageDialog(Hlavni.okno, "Zadan� znak nen� prvkem vstupn� abecedy.\n"
					+ "Automat ho bude ignorovat.",	"Chyba vstupu", JOptionPane.WARNING_MESSAGE);
			return false;
		}else{
			return Hlavni.automat.zpracujVstupReverse(c);
		}
	}
	
//===================================================================================================================	
	/**
	 * Zajistuje ukonceni programu.
	 */
	class KonecAkce extends AbstractAction {
		/** defaultni nastaveni */
		private static final long serialVersionUID = 1L;
		
		/**
		 * Konstruktor nastavi popis tlacitka a klavesove zkratky.
		 */
		public KonecAkce() {
			putValue(NAME, "Konec"); // jmeno akce
            putValue(SHORT_DESCRIPTION, "Ukon�� aplikaci"); // popis tlacitka
            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_K)); // klavesova zkratka pro navigaci v menu
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_E, ActionEvent.CTRL_MASK)); // klavesova zkratka, funguje vzdy
		}
		
		/**
		 * Ukonci aplikaci.
		 */
		public void actionPerformed(ActionEvent e) {
			Hlavni.automat.close();
			System.exit(0);
		}
	}

	
	//===================================================================================================================	
		/**
		 * Zajistuje ukonceni logovani automatu.
		 */
		class KonecLoguAkce extends AbstractAction {
			/** defaultni nastaveni */
			private static final long serialVersionUID = 1L;
			
			/**
			 * Konstruktor nastavi popis tlacitka a klavesove zkratky.
			 */
			public KonecLoguAkce() {
				putValue(NAME, "Konec logov�n� automatu"); // jmeno akce
	            putValue(SHORT_DESCRIPTION, "Ukon�� z�pis akc� automatu do souboru."); // popis tlacitka
	       }
			
			/**
			 * Ukonci logovani automatu.
			 */
			public void actionPerformed(ActionEvent e) {
				Hlavni.automat.close();
			}
		}

		//===================================================================================================================	
		/**
		 * Zajistuje zacatek logovani automatu.
		 */
		class StartLogAkce extends AbstractAction {
			/** defaultni nastaveni */
			private static final long serialVersionUID = 1L;
			
			/**
			 * Konstruktor nastavi popis tlacitka a klavesove zkratky.
			 */
			public StartLogAkce() {
				putValue(NAME, "Start logov�n� automatu"); // jmeno akce
	            putValue(SHORT_DESCRIPTION, "Zapne z�pis akc� automatu do zvolen�ho souboru"); // popis tlacitka
	           }
			
			/**
			 * Zacne logovat do automatu.
			 */
			public void actionPerformed(ActionEvent e) {
				String file = JOptionPane.showInputDialog(Hlavni.okno, "Zadej n�zev souboru logu");
				Hlavni.automat.startLogovaniAutomatu(file);
			}
		}

	
	
//===================================================================================================================
	
	/**
	 * Zajistuje akci otevreni okna s napovedou.
	 */
	class NapovedaAkce extends AbstractAction {
		/**	defaultni nastaveni */
		private static final long serialVersionUID = 1L;

		/**
		 * Konstruktor vytvori akci tlacitko s ikonkou, 
		 * jmenem a mnemonic a accelerator klavesovou zkratkou.
		 */
		public NapovedaAkce() {
            putValue(NAME, "N�pov�da"); // jmeno akce
            putValue(SHORT_DESCRIPTION, "Zobraz� n�pov�du k aplikaci"); // popis tlacitka
            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_N)); // klavesova zkratka pro navigaci v menu
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_H, ActionEvent.CTRL_MASK)); // klavesova zkratka, funguje vzdy
		}
		
		/**
		 * Metoda zajisti provedeni akce.
		 */
		public void actionPerformed(ActionEvent e) {
			new NapovedaOkno();
		}
	}
	
//===================================================================================================================

	/**
	 * Zajistuje nacteni automatu ze souboru
	 */
	class NactiAutomatSouborAkce extends AbstractAction {
		/** defaultni nastaveni */
		private static final long serialVersionUID = 1L;
		
		/**
		 * Konstruktor vytvori popis tlacitka a klavesove zkratky.
		 */
		public NactiAutomatSouborAkce() {
            putValue(NAME, "Na��st automat ze souboru..."); // jmeno akce
            putValue(SHORT_DESCRIPTION, "Na�te automat ze souboru"); // popis tlacitka
            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_A)); // klavesova zkratka pro navigaci v menu
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK)); // klavesova zkratka, funguje vzdy
		}
	
		/**
		 * Nacte automat ze souboru.
		 */
		public void actionPerformed(ActionEvent e) {	
			JFileChooser oteviraciDialog = new JFileChooser("."); // "." znamena aktualni adresar
			
			File vstupni = null;
			String filepath = "";
			
			if (oteviraciDialog.showOpenDialog(Hlavni.okno) == JFileChooser.APPROVE_OPTION) { // nacte data ze souboru				
				vstupni = new File(oteviraciDialog.getSelectedFile().getAbsolutePath());
				filepath = vstupni.getAbsolutePath();
				
				Hlavni.stavy = Loader.loadStavy(filepath);
				Hlavni.automat = Loader.loadAutomat(filepath);
				Hlavni.stavy.get(Hlavni.automat.getAktualniStav()).setBarva(Stav.AKTIVNI);
				
				if(Hlavni.automat != null && Hlavni.stavy!=null){
					Akce.reset.actionPerformed(e);
					Hlavni.okno.repaint();
				}else{
					System.out.println("Data nebyla korektn� na�tena.");
				}
				Hlavni.automat.close();
			}
			
		}
	}
	
//===================================================================================================================
	
	/**
	 * Zajistuje reset automatu do pocatecniho stavu
	 */
	class ResetAkce extends AbstractAction {
		/** defaultni nastaveni */
		private static final long serialVersionUID = 1L;
		
		/**
		 * Konstruktor vytvori popis tlacitka a klavesove zkratky.
		 */
		public ResetAkce() {
            putValue(NAME, "Reset"); // jmeno akce
            putValue(SHORT_DESCRIPTION, "Nastav� automat do v�choz�ho (po��te�n�ho) stavu."); // popis tlacitka
            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_R)); // klavesova zkratka pro navigaci v menu
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.CTRL_MASK)); // klavesova zkratka, funguje vzdy
		}
	
		/**
		 * Resetuje automat.
		 */
		public void actionPerformed(ActionEvent e) {
			Hlavni.getAktualniStav().setBarva(Stav.BEZNY);
			Hlavni.automat.reset();
			Hlavni.getAktualniStav().setBarva(Stav.AKTIVNI);
			
			Hlavni.okno.vstup.setText("");
			Hlavni.okno.zpracovany.setText("");
			Hlavni.okno.vystupni_retezec.setText(""+Hlavni.automat.getVystup());

			Hlavni.okno.repaint();
			
		}
	}
	
//===================================================================================================================

	/**
	 * Zajistuje zpracovani znaku automatem
	 */
	class ZnakAkce extends AbstractAction {
		/** defaultni nastaveni */
		private static final long serialVersionUID = 1L;
		
		/**
		 * Konstruktor vytvori popis tlacitka a klavesove zkratky.
		 */
		public ZnakAkce() {
            putValue(NAME, "Vstup znaku"); // jmeno akce
            putValue(SHORT_DESCRIPTION, "Provede krok automatu"); // popis tlacitka
            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_N)); // klavesova zkratka pro navigaci v menu
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK)); // klavesova zkratka, funguje vzdy
		}
	
		/**
		 * Zpracuje znak.
		 */
		public void actionPerformed(ActionEvent e) {
			Hlavni.getAktualniStav().setBarva(Stav.BEZNY);
			
			String vstup = JOptionPane.showInputDialog(Hlavni.okno, "Zadej jeden znak pro zpracov�n� automatem", "Zadej znak", JOptionPane.DEFAULT_OPTION);
			if(vstup!=null){
					vstup = vstup.trim();
				if(vstup.length()>0){
					char ch = vstup.charAt(0);
					if(vpred(ch)){
						Hlavni.okno.zpracovany.setText(Hlavni.okno.zpracovany.getText()+ch);
						Hlavni.okno.vystupni_retezec.setText(
								Hlavni.okno.vystupni_retezec.getText()+Hlavni.automat.getVystup());
					}else{
						JOptionPane.showMessageDialog(Hlavni.okno, "Pro znak "+ch+" nen� definovan� p�echodov� funkce\n"
								+ "Automat ho bude ignorovat.",	"Chyba vstupu", JOptionPane.WARNING_MESSAGE);
					}
				}
			}
			Hlavni.getAktualniStav().setBarva(Stav.AKTIVNI);
			Hlavni.okno.repaint();
		}
	}
	
//===================================================================================================================

	/**
	 * Zajistuje nacteni znaku do vstupniho pole
	 */
	class NactiRetezecAkce extends AbstractAction {
		/** defaultni nastaveni */
		private static final long serialVersionUID = 1L;
		
		/**
		 * Konstruktor vytvori popis tlacitka a klavesove zkratky.
		 */
		public NactiRetezecAkce() {
            putValue(NAME, "Vstup �et�zce"); // jmeno akce
            putValue(SHORT_DESCRIPTION, "Na�te �et�zec znak� ke zpracov�n� automatem"); // popis tlacitka
            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_T)); // klavesova zkratka pro navigaci v menu
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_T, ActionEvent.CTRL_MASK)); // klavesova zkratka, funguje vzdy
		}
	
		/**
		 * Nacte retezec.
		 */
		public void actionPerformed(ActionEvent e) {	
			String vstup = JOptionPane.showInputDialog(Hlavni.okno, "�et�zec pro zpracov�n� automatem", "Zadej �et�zec", JOptionPane.DEFAULT_OPTION);
			if(vstup!=null){
					vstup = vstup.trim();
				if(vstup.length()>0){
					Hlavni.okno.vstup.setText(vstup);
				}
			}
			Hlavni.okno.repaint();
		}
	}
	
	/**
	 * Zajistuje nacteni retezce ze souboru do vstupniho pole
	 */
	class NactiRetezecSouborAkce extends AbstractAction {
		/** defaultni nastaveni */
		private static final long serialVersionUID = 1L;
		
		/**
		 * Konstruktor vytvori popis tlacitka a klavesove zkratky.
		 */
		public NactiRetezecSouborAkce() {
            putValue(NAME, "Na��st vstup ze souboru..."); // jmeno akce
            putValue(SHORT_DESCRIPTION, "Na�te �et�zec znak� ke zpracov�n� automatem ze souboru"); // popis tlacitka
            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_V)); // klavesova zkratka pro navigaci v menu
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK)); // klavesova zkratka, funguje vzdy
		}
	
		/**
		 * Nacte retezec ze souboru.
		 */
		public void actionPerformed(ActionEvent e) {	
			JFileChooser oteviraciDialog = new JFileChooser("."); // "." znamena aktualni adresar
			File vstupni = null;
			String vstup = "";
			
			if (oteviraciDialog.showOpenDialog(Hlavni.okno) == JFileChooser.APPROVE_OPTION) { // nacte data ze souboru				
				Scanner sc;
				try {
					vstupni = new File(oteviraciDialog.getSelectedFile().getAbsolutePath());
					sc = new Scanner(vstupni);
					if(!sc.hasNext()){
						//pokud nen� co ��st ute�...
						JOptionPane.showMessageDialog(Hlavni.okno, "V souboru nen� validn� �et�zec.", "Chyba vstupu", JOptionPane.WARNING_MESSAGE);
						sc.close();
						return;
					}
					vstup = sc.next();
					sc.close();
					
					if(vstup!=null){
							vstup = vstup.trim();
						if(vstup.length()>0){
							Hlavni.okno.vstup.setText(vstup);
						}
					}
				} catch (IOException e1) {
					System.out.println("Chyba p�i �ten� souboru.");
				}
			}
			
			Hlavni.okno.repaint();
		}
	}
//====================================================================================================================

	/**
	 * Zajistuje zpracovani znaku automatem
	 */
	class KrokVpredAkce extends AbstractAction {
		/** defaultni nastaveni */
		private static final long serialVersionUID = 1L;
		
		/**
		 * Konstruktor vytvori popis tlacitka a klavesove zkratky.
		 */
		public KrokVpredAkce() {
            putValue(NAME, "Krok vp�ed"); // jmeno akce
            putValue(SHORT_DESCRIPTION, "Zpracuje jeden znak"); // popis tlacitka
            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_P)); // klavesova zkratka pro navigaci v menu
            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_U, ActionEvent.CTRL_MASK)); // klavesova zkratka, funguje vzdy
		}
	
		/**
		 * Zpracuje znak (posune automat o krok vpred).
		 */
		public void actionPerformed(ActionEvent e) {	
			Hlavni.getAktualniStav().setBarva(Stav.BEZNY);
			
			String vstup = Hlavni.okno.vstup.getText().trim();
			if(vstup != null && vstup.length()>0){
				char c = vstup.charAt(0);
				if(vpred(c)){
					Hlavni.okno.zpracovany.setText(Hlavni.okno.zpracovany.getText()+c);	
					Hlavni.okno.vystupni_retezec.setText(
							Hlavni.okno.vystupni_retezec.getText()+Hlavni.automat.getVystup());
				}
				else{
					JOptionPane.showMessageDialog(Hlavni.okno, "Pro znak "+c+" nen� definovan� p�echodov� funkce\n"
							+ "Automat ho bude ignorovat.",	"Chyba vstupu", JOptionPane.WARNING_MESSAGE);
				}
				Hlavni.okno.vstup.setText(vstup.substring(1));
			}
			
			Hlavni.getAktualniStav().setBarva(Stav.AKTIVNI);
			Hlavni.okno.repaint();
		}
	}
//====================================================================================================================

		/**
		 * Zajistuje vraceni zaku z vystupu na vstup
		 */
		class KrokVzadAkce extends AbstractAction {
			/** defaultni nastaveni */
			private static final long serialVersionUID = 1L;
			
			/**
			 * Konstruktor vytvori popis tlacitka a klavesove zkratky.
			 */
			public KrokVzadAkce() {
	            putValue(NAME, "Krok vzad"); // jmeno akce
	            putValue(SHORT_DESCRIPTION, "Posledn� znak na v�stupu bude prvn�m znakem na vstupu"); // popis tlacitka
	            putValue(MNEMONIC_KEY, new Integer(KeyEvent.VK_Z)); // klavesova zkratka pro navigaci v menu
	            putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_Z, ActionEvent.CTRL_MASK)); // klavesova zkratka, funguje vzdy
			}
		
			/**
			 * Vrati automat o krok zpet (posledni znak na vystupu bude prvnim znakem na vstupu).
			 */
			public void actionPerformed(ActionEvent e) {	
				Hlavni.getAktualniStav().setBarva(Stav.BEZNY);
				
				String vystup = Hlavni.okno.zpracovany.getText().trim();
				if(vystup != null && vystup.length()>0){
					char c = vystup.charAt(vystup.length()-1);
					vzad(c);
					
					Hlavni.okno.vstup.setText(c+Hlavni.okno.vstup.getText());
					Hlavni.okno.zpracovany.setText(vystup.substring(0,vystup.length()-1));
					
					String tmp = Hlavni.okno.vystupni_retezec.getText();
					if(tmp.length()>0){
						Hlavni.okno.vystupni_retezec.setText(tmp.substring(0,tmp.length()-1));
					}else{
						Hlavni.okno.vystupni_retezec.setText("");
					}
					
				}
				
				Hlavni.getAktualniStav().setBarva(Stav.AKTIVNI);
				Hlavni.okno.repaint();
			}
		}
}
